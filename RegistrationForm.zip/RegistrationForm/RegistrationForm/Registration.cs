﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RegistrationForm
{
    public partial class Registration : Form
    {
        Login logn = new Login();
        public System.Windows.Forms.TextBox textBox1InForm1;

        public Registration()
        {
            InitializeComponent();
        }

        private void btnreg_Click(object sender, EventArgs e)
        {

            if (txtuserName.Text != "" && txtpwd.Text != "")
            {
               
                logn.username = txtuserName.Text;
                logn.password = txtpwd.Text;
                logn.email = txtemail.Text;
                logn.seccode = txtSec.Text;
                this.Hide();
                logn.Show();
            }
           
            }

       }
}
