﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeathCalculator
{
    public partial class deathform : Form
    {
        public deathform()
        {
            InitializeComponent();
        }


        private void calcdeathdate(DateTime birthdate, int year, int month, int day) 
        {
            DateTime deathDate = birthdate.AddDays(day).AddMonths(month).AddYears(year);
            MessageBox.Show("Your expected death date : " + deathDate.ToString("dd/MM/yyyy"));

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "")
            {
                MessageBox.Show("Enter the Name");
                return;
            }

            if (!rdbmale.Checked && !rdbfemale.Checked)
            {
                MessageBox.Show("Enter the Gender");
                return;
            }

            if (txtyear.Text == "" || txtmonth.Text == "" || txtday.Text == "")
            {
                MessageBox.Show("Enter the Birth Date");
                return;
            }

            //Create birthdate variable using the values entered by the user            
            DateTime birthDate = new DateTime(Convert.ToInt32(txtyear.Text) , Convert.ToInt32(txtmonth.Text), Convert.ToInt32(txtday.Text));
            DateTime currentDate = DateTime.Now ;
            if (((currentDate - birthDate).TotalDays / 365) < 17)
            {
                MessageBox.Show("Age less than 17 years");
                return;
            }

            if (chkalcohol.Checked && chksmoking.Checked == false)
            {

                calcdeathdate(birthDate, 60, 12, 5);

            }
            else if (!chkalcohol.Checked && !chksmoking.Checked)
             {
                 calcdeathdate(birthDate, 55, 12, 5);                 

             }
             else if (chkalcohol.Checked == false && chksmoking.Checked)
             {
                 calcdeathdate(birthDate, 50, 5, 10);
             }
            else if (chkalcohol.Checked && chksmoking.Checked == false)
            {
                calcdeathdate(birthDate, 45, 2, 15);
            }
             else if (chkalcohol.Checked && chksmoking.Checked)
             {
                 calcdeathdate(birthDate, 40, 1, 25); 
             }
             else if (chkalcohol.Checked ==false && chksmoking.Checked)
             {
                 calcdeathdate(birthDate, 35, 6, 15); 
             }
            else if (chkalcohol.Checked == false && chksmoking.Checked == false)
            {
                calcdeathdate(birthDate, 75, 1, 10); 
            }
            else if (chkalcohol.Checked && chksmoking.Checked)
            {
                calcdeathdate(birthDate, 25, 12, 1); 
            }

        }

        private void chkalcohol_CheckedChanged(object sender, EventArgs e)
        {
            //Create birthdate variable using the values entered by the user            
            DateTime birthDate = new DateTime(Convert.ToInt32(txtyear.Text), Convert.ToInt32(txtmonth.Text), Convert.ToInt32(txtday.Text));
            DateTime currentDate = DateTime.Now;
            if (((currentDate - birthDate).TotalDays / 365) < 17)
            {
                MessageBox.Show("Age cannot be less than 17 years");
                chkalcohol.Checked = false;
                return;
            }
            radioButton1.Enabled = chkalcohol.Checked;
            radioButton2.Enabled = chkalcohol.Checked;
            radioButton3.Enabled = chkalcohol.Checked;
        }

        private void chksmoking_CheckedChanged(object sender, EventArgs e)
        {
            //Create birthdate variable using the values entered by the user            
            DateTime birthDate = new DateTime(Convert.ToInt32(txtyear.Text), Convert.ToInt32(txtmonth.Text), Convert.ToInt32(txtday.Text));
            DateTime currentDate = DateTime.Now;
            if (((currentDate - birthDate).TotalDays / 365) < 17)
            {
                MessageBox.Show("Age cannot be less than 17 years");
                chksmoking.Checked = false;
                return;
            }
            radioButton4.Enabled = chksmoking.Checked;
            radioButton5.Enabled = chksmoking.Checked;
            radioButton6.Enabled = chksmoking.Checked;
            radioButton7.Enabled = chksmoking.Checked;
            radioButton8.Enabled = chksmoking.Checked;
            radioButton9.Enabled = chksmoking.Checked;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            //Create birthdate variable using the values entered by the user            
            DateTime birthDate = new DateTime(Convert.ToInt32(txtyear.Text), Convert.ToInt32(txtmonth.Text), Convert.ToInt32(txtday.Text));
            DateTime currentDate = DateTime.Now;
            int maxDate = Convert.ToInt32((currentDate - birthDate).TotalDays / 365 );

            if (radioButton4.Checked)
            {
                if (maxDate < 18)
                {
                    MessageBox.Show("Age Error");
                    radioButton4.Checked = false;
                }
            }
            else if (radioButton5.Checked)
            {
                if (maxDate < 22)
                {
                    MessageBox.Show("Age Error");
                    radioButton5.Checked = false;
                }
            }
            else if (radioButton6.Checked)
            {
                if (maxDate < 27)
                {
                    MessageBox.Show("Age Error");
                    radioButton6.Checked = false;
                }
            }

            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            //Create birthdate variable using the values entered by the user            
            DateTime birthDate = new DateTime(Convert.ToInt32(txtyear.Text), Convert.ToInt32(txtmonth.Text), Convert.ToInt32(txtday.Text));
            DateTime currentDate = DateTime.Now;
            int maxDate = Convert.ToInt32((currentDate - birthDate).TotalDays / 365);

            if (radioButton1.Checked)
            {
                if (maxDate < 18)
                {
                    MessageBox.Show("Age Error");
                    radioButton1.Checked = false;
                }
            }
            else if (radioButton2.Checked)
            {
                if (maxDate < 22)
                {
                    MessageBox.Show("Age Error");
                    radioButton2.Checked = false;
                }
            }
            else if (radioButton3.Checked)
            {
                if (maxDate < 27)
                {
                    MessageBox.Show("Age Error");
                    radioButton3.Checked = false;
                }
            }
        }
    }
}
