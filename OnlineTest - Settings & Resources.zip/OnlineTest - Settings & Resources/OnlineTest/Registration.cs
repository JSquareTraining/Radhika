﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace OnlineTest
{
    public partial class Registration : Form
    {

        Properties.Settings objProp = new Properties.Settings();
        public Registration()
        {
            InitializeComponent();
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
                       
             ResourceManager orm = new ResourceManager("OnlineTest.properties.c", Assembly.GetExecutingAssembly());
            
            string name = "";
            string gender = "";

            if (txtname.Text == "")
            {
                MessageBox.Show("No Name Entered");
                return;
            }
            else
            {
                name = txtname.Text;
            }

            if (!(rdbMale.Checked || rdbFemale.Checked))
            {
                MessageBox.Show("No Gender Selected");
                return;
            }
            else
            {
                if (rdbMale.Checked)
                    gender = "Male";
                else
                    gender = "FeMale";
            }

            if (!(checkBoxC.Checked || checkBoxCplus.Checked || checkBoxDotNet.Checked))
            {
                MessageBox.Show("No Test Selected");
                return;
            }


            Results resultForm = new Results();
            resultForm.regForm = this;
            if (checkBoxC.Checked == true)
            {
                this.Hide();
                
                c cselected = new c();
                
                //update the question set
                if (objProp.c == 3)
                {
                    objProp.c = 1;
                }
                else
                {
                    objProp.c = objProp.c + 1;
                }
                objProp.Save();

                resultForm.cForm = cselected;
                cselected.resultForm = resultForm;
                cselected.Show();

                return;
            }
            if (checkBoxCplus.Checked == true)
            {
                this.Hide();
                cplusplus cplusselected = new cplusplus();

                //update the question set
                if (objProp.cplus == 3)
                {
                    objProp.cplus = 1;
                }
                else
                {
                    objProp.cplus = objProp.cplus + 1;
                }
                objProp.Save();

                resultForm.cplusplusForm = cplusselected;
                cplusselected.resultForm = resultForm;
                cplusselected.Show();
                return;
            }
            if (checkBoxDotNet.Checked == true)
            {
                this.Hide();
                vbdotnet vbdotnetselected = new vbdotnet();

                //update the question set
                if (objProp.vbdotnet == 3)
                {
                    objProp.vbdotnet = 1;
                }
                else
                {
                    objProp.vbdotnet = objProp.vbdotnet + 1;
                }
                objProp.Save();

                resultForm.vbdotnetForm = vbdotnetselected;
                vbdotnetselected.resultForm = resultForm;
                vbdotnetselected.Show();
                return;
            }

            if (checkBoxCplus.Checked == true)
            {
                this.Hide();
                
            }
        }
    }
}
