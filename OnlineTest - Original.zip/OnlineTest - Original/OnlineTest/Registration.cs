﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OnlineTest
{
    public partial class Registration : Form
    {

        public Registration()
        {
            InitializeComponent();


        }


        private void btnnext_Click(object sender, EventArgs e)
        {

            string name = "";
            string gender = "";

            if (txtname.Text == "")
            {
                MessageBox.Show("No Name Entered");
                return;
            }
            else
            {
                name = txtname.Text;
            }

            if (!(rdbMale.Checked || rdbFemale.Checked))
            {
                MessageBox.Show("No Gender Selected");
                return;
            }
            else
            {
                if (rdbMale.Checked)
                    gender = "Male";
                else
                    gender = "FeMale";
            }

            if (!(checkBoxC.Checked || checkBoxCplus.Checked || checkBoxDotNet.Checked))
            {
                MessageBox.Show("No Test Selected");
                return;
            }

            Results resultForm = new Results();
            resultForm.regForm = this;
            if (checkBoxC.Checked == true)
            {
                this.Hide();
                c cselected = new c();
                resultForm.cForm = cselected;
                cselected.resultForm = resultForm;
                cselected.Show();
                return;
            }
            if (checkBoxCplus.Checked == true)
            {
                this.Hide();
                cplusplus cplusselected = new cplusplus();
                resultForm.cplusplusForm = cplusselected;
                cplusselected.resultForm = resultForm;
                cplusselected.Show();
                return;
            }
            if (checkBoxDotNet.Checked == true)
            {
                this.Hide();
                vbdotnet vbdotnetselected = new vbdotnet();
                resultForm.vbdotnetForm = vbdotnetselected;
                vbdotnetselected.resultForm = resultForm;
                vbdotnetselected.Show();
                return;
            }
            

        }
    }
}
