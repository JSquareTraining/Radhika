﻿namespace OnlineTest
{
    partial class Results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcpq5 = new System.Windows.Forms.Label();
            this.lblcpq4 = new System.Windows.Forms.Label();
            this.lblcpq3 = new System.Windows.Forms.Label();
            this.lblcpq2 = new System.Windows.Forms.Label();
            this.lblcpq1 = new System.Windows.Forms.Label();
            this.lblcq5 = new System.Windows.Forms.Label();
            this.lblcq4 = new System.Windows.Forms.Label();
            this.lblcq3 = new System.Windows.Forms.Label();
            this.lblcq2 = new System.Windows.Forms.Label();
            this.lblcq1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblvbq1 = new System.Windows.Forms.Label();
            this.lblvbq2 = new System.Windows.Forms.Label();
            this.lblvbq3 = new System.Windows.Forms.Label();
            this.lblvbq4 = new System.Windows.Forms.Label();
            this.lblvbq5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblcpq5
            // 
            this.lblcpq5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcpq5.Location = new System.Drawing.Point(266, 15);
            this.lblcpq5.Name = "lblcpq5";
            this.lblcpq5.Size = new System.Drawing.Size(16, 16);
            this.lblcpq5.TabIndex = 30;
            // 
            // lblcpq4
            // 
            this.lblcpq4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcpq4.Location = new System.Drawing.Point(218, 15);
            this.lblcpq4.Name = "lblcpq4";
            this.lblcpq4.Size = new System.Drawing.Size(16, 16);
            this.lblcpq4.TabIndex = 29;
            // 
            // lblcpq3
            // 
            this.lblcpq3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcpq3.Location = new System.Drawing.Point(174, 15);
            this.lblcpq3.Name = "lblcpq3";
            this.lblcpq3.Size = new System.Drawing.Size(16, 16);
            this.lblcpq3.TabIndex = 28;
            // 
            // lblcpq2
            // 
            this.lblcpq2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcpq2.Location = new System.Drawing.Point(129, 15);
            this.lblcpq2.Name = "lblcpq2";
            this.lblcpq2.Size = new System.Drawing.Size(16, 16);
            this.lblcpq2.TabIndex = 27;
            // 
            // lblcpq1
            // 
            this.lblcpq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcpq1.Location = new System.Drawing.Point(83, 15);
            this.lblcpq1.Name = "lblcpq1";
            this.lblcpq1.Size = new System.Drawing.Size(16, 16);
            this.lblcpq1.TabIndex = 26;
            // 
            // lblcq5
            // 
            this.lblcq5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcq5.Location = new System.Drawing.Point(266, 14);
            this.lblcq5.Name = "lblcq5";
            this.lblcq5.Size = new System.Drawing.Size(16, 16);
            this.lblcq5.TabIndex = 25;
            // 
            // lblcq4
            // 
            this.lblcq4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcq4.Location = new System.Drawing.Point(218, 14);
            this.lblcq4.Name = "lblcq4";
            this.lblcq4.Size = new System.Drawing.Size(16, 16);
            this.lblcq4.TabIndex = 24;
            // 
            // lblcq3
            // 
            this.lblcq3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcq3.Location = new System.Drawing.Point(174, 14);
            this.lblcq3.Name = "lblcq3";
            this.lblcq3.Size = new System.Drawing.Size(16, 16);
            this.lblcq3.TabIndex = 23;
            // 
            // lblcq2
            // 
            this.lblcq2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcq2.Location = new System.Drawing.Point(129, 14);
            this.lblcq2.Name = "lblcq2";
            this.lblcq2.Size = new System.Drawing.Size(16, 16);
            this.lblcq2.TabIndex = 22;
            // 
            // lblcq1
            // 
            this.lblcq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcq1.Location = new System.Drawing.Point(83, 14);
            this.lblcq1.Name = "lblcq1";
            this.lblcq1.Size = new System.Drawing.Size(16, 16);
            this.lblcq1.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "C++";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "C";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = ".NET";
            // 
            // lblvbq1
            // 
            this.lblvbq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvbq1.Location = new System.Drawing.Point(83, 16);
            this.lblvbq1.Name = "lblvbq1";
            this.lblvbq1.Size = new System.Drawing.Size(16, 16);
            this.lblvbq1.TabIndex = 31;
            // 
            // lblvbq2
            // 
            this.lblvbq2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvbq2.Location = new System.Drawing.Point(129, 16);
            this.lblvbq2.Name = "lblvbq2";
            this.lblvbq2.Size = new System.Drawing.Size(16, 16);
            this.lblvbq2.TabIndex = 32;
            // 
            // lblvbq3
            // 
            this.lblvbq3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvbq3.Location = new System.Drawing.Point(174, 16);
            this.lblvbq3.Name = "lblvbq3";
            this.lblvbq3.Size = new System.Drawing.Size(16, 16);
            this.lblvbq3.TabIndex = 33;
            // 
            // lblvbq4
            // 
            this.lblvbq4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvbq4.Location = new System.Drawing.Point(218, 16);
            this.lblvbq4.Name = "lblvbq4";
            this.lblvbq4.Size = new System.Drawing.Size(16, 16);
            this.lblvbq4.TabIndex = 34;
            // 
            // lblvbq5
            // 
            this.lblvbq5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvbq5.Location = new System.Drawing.Point(266, 16);
            this.lblvbq5.Name = "lblvbq5";
            this.lblvbq5.Size = new System.Drawing.Size(16, 16);
            this.lblvbq5.TabIndex = 35;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblcq5);
            this.groupBox1.Controls.Add(this.lblcq4);
            this.groupBox1.Controls.Add(this.lblcq3);
            this.groupBox1.Controls.Add(this.lblcq2);
            this.groupBox1.Controls.Add(this.lblcq1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(65, 84);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(311, 46);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblcpq5);
            this.groupBox2.Controls.Add(this.lblcpq4);
            this.groupBox2.Controls.Add(this.lblcpq3);
            this.groupBox2.Controls.Add(this.lblcpq2);
            this.groupBox2.Controls.Add(this.lblcpq1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(65, 157);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(309, 43);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblvbq5);
            this.groupBox3.Controls.Add(this.lblvbq4);
            this.groupBox3.Controls.Add(this.lblvbq3);
            this.groupBox3.Controls.Add(this.lblvbq2);
            this.groupBox3.Controls.Add(this.lblvbq1);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(65, 226);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(304, 44);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            // 
            // Results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 351);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Results";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Results";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblcpq5;
        private System.Windows.Forms.Label lblcpq4;
        private System.Windows.Forms.Label lblcpq3;
        private System.Windows.Forms.Label lblcpq2;
        private System.Windows.Forms.Label lblcpq1;
        private System.Windows.Forms.Label lblcq5;
        private System.Windows.Forms.Label lblcq4;
        private System.Windows.Forms.Label lblcq3;
        private System.Windows.Forms.Label lblcq2;
        private System.Windows.Forms.Label lblcq1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblvbq1;
        private System.Windows.Forms.Label lblvbq2;
        private System.Windows.Forms.Label lblvbq3;
        private System.Windows.Forms.Label lblvbq4;
        private System.Windows.Forms.Label lblvbq5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}