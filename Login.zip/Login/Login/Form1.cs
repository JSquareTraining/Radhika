﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            
            if (txt1.Text != "" && txt2.Text == "")
            {
                MessageBox.Show("Password is Empty");
                this.Close();
            }
            else if (txt1.Text == "" && txt2.Text != "")
            {
                MessageBox.Show("Username is Empty");
                this.Close();
            }
            else if (txt1.Text == "Admin" && txt2.Text == "Admin")
            {
                MessageBox.Show("Login Successful");
                this.Close();
            }
            else if (txt1.Text != "Admin" && txt2.Text == "Admin")
            {
                MessageBox.Show(" Wrong Username Only 2 Chances Left");
                this.Close();
            }
            else if (txt1.Text == "Admin" && txt2.Text != "Admin")
            {
                MessageBox.Show(" Wrong Password Only 1 Chance Left");
                this.Close();
            }
            else if (txt1.Text != "" && txt2.Text != "")
            {
                MessageBox.Show(" Wrong Username and Password Sorry! Chance Over ");
                this.Close();
            }
            {
                MessageBox.Show(" Username & Password Empty");
                this.Close();
            }

        }
    }
        
}
