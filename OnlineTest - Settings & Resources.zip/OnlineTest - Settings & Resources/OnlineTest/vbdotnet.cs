﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace OnlineTest
{
    public partial class vbdotnet : Form
    {
        ResourceManager orm = new ResourceManager("OnlineTest.properties.vb", Assembly.GetExecutingAssembly());
        Properties.Settings ops = new Properties.Settings();
        public Results resultForm = null;
        public vbdotnet()
        {
            InitializeComponent();
            updateQuestions();
        }

        private void updateQuestions()
        {
            int questionSet = ops.vbdotnet;

            label1.Text = "1. "+orm.GetString("vbq" + questionSet + "1");
            radioButtonq11.Text = orm.GetString("vbq" + questionSet + "1op1");
            radioButtonq12.Text = orm.GetString("vbq" + questionSet + "1op2");
            radioButtonq13.Text = orm.GetString("vbq" + questionSet + "1op3");
            radioButtonq14.Text = orm.GetString("vbq" + questionSet + "1op4");

            label2.Text = "2. "+orm.GetString("vbq" + questionSet + "2");
            radioButtonq21.Text = orm.GetString("vbq" + questionSet + "2op1");
            radioButtonq22.Text = orm.GetString("vbq" + questionSet + "2op2");
            radioButtonq23.Text = orm.GetString("vbq" + questionSet + "2op3");
            radioButtonq24.Text = orm.GetString("vbq" + questionSet + "2op4");

            label3.Text = "3. "+orm.GetString("vbq" + questionSet + "3");
            radioButtonq31.Text = orm.GetString("vbq" + questionSet + "3op1");
            radioButtonq32.Text = orm.GetString("vbq" + questionSet + "3op2");
            radioButtonq33.Text = orm.GetString("vbq" + questionSet + "3op3");
            radioButtonq34.Text = orm.GetString("vbq" + questionSet + "3op4");

            label4.Text = "4. "+orm.GetString("vbq" + questionSet + "4");
            radioButtonq41.Text = orm.GetString("vbq" + questionSet + "4op1");
            radioButtonq42.Text = orm.GetString("vbq" + questionSet + "4op2");
            radioButtonq43.Text = orm.GetString("vbq" + questionSet + "4op3");
            radioButtonq44.Text = orm.GetString("vbq" + questionSet + "4op4");

            label5.Text = "5. "+orm.GetString("vbq" + questionSet + "5");
            radioButtonq51.Text = orm.GetString("vbq" + questionSet + "5op1");
            radioButtonq52.Text = orm.GetString("vbq" + questionSet + "5op2");
            radioButtonq53.Text = orm.GetString("vbq" + questionSet + "5op3");
            radioButtonq54.Text = orm.GetString("vbq" + questionSet + "5op4");


        }

        public bool cVbLang;
        public bool cVbplusPlus;
        public bool vVbbdotnet;

        private void btnNext_Click(object sender, EventArgs e)
        {

            if (!(radioButtonq11.Checked || radioButtonq12.Checked || radioButtonq13.Checked || radioButtonq14.Checked))
            {
                MessageBox.Show("No choice selected for question 1");
                return;
            }
            if (!(radioButtonq21.Checked || radioButtonq22.Checked || radioButtonq23.Checked || radioButtonq24.Checked))
            {
                MessageBox.Show("No choice selected for question 2");
                return;
            }
            if (!(radioButtonq31.Checked || radioButtonq32.Checked || radioButtonq33.Checked || radioButtonq34.Checked))
            {
                MessageBox.Show("No choice selected for question 3");
                return;
            }
            if (!(radioButtonq41.Checked || radioButtonq42.Checked || radioButtonq43.Checked || radioButtonq44.Checked))
            {
                MessageBox.Show("No choice selected for question 4");
                return;
            }
            if (!(radioButtonq51.Checked || radioButtonq52.Checked || radioButtonq53.Checked || radioButtonq54.Checked))
            {
                MessageBox.Show("No choice selected for question 5");
                return;
            }

            this.Hide();
            resultForm.displayResults();
            resultForm.Show();
            
        }

        private RadioButton getCheckedRadioButton(Control container)
        {
            foreach (var control in container.Controls)
            {
                RadioButton rdb = control as RadioButton;
                if (rdb != null && rdb.Checked)
                    return rdb;
            }
            return null;
        }

        public Boolean getResult(int c)
        {
            int questionSet = ops.vbdotnet;
            if (c == 1)
            {
                RadioButton rdb = getCheckedRadioButton(panel1);
                if (rdb != null)
                {
                    string correctans = orm.GetString("vbq" + questionSet + "1a");
                    if (Convert.ToString(rdb.Tag).Equals(correctans))
                        return true;
                    else
                        return false;

                }

            }

            if (c == 2)
            {
                RadioButton rdb = getCheckedRadioButton(panel2);
                if (rdb != null)
                {
                    string correctans = orm.GetString("vbq" + questionSet + "2a");
                    if (Convert.ToString(rdb.Tag).Equals(correctans))
                        return true;
                    else
                        return false;

                }

            }

            if (c == 3)
            {
                RadioButton rdb = getCheckedRadioButton(panel3);
                if (rdb != null)
                {
                    string correctans = orm.GetString("vbq" + questionSet + "3a");
                    if (Convert.ToString(rdb.Tag).Equals(correctans))
                        return true;
                    else
                        return false;

                }

            }

            if (c == 4)
            {
                RadioButton rdb = getCheckedRadioButton(panel4);
                if (rdb != null)
                {
                    string correctans = orm.GetString("vbq" + questionSet + "4a");
                    if (Convert.ToString(rdb.Tag).Equals(correctans))
                        return true;
                    else
                        return false;

                }

            }

            if (c == 5)
            {
                RadioButton rdb = getCheckedRadioButton(panel5);
                if (rdb != null)
                {
                    string correctans = orm.GetString("vbq" + questionSet + "5a");
                    if (Convert.ToString(rdb.Tag).Equals(correctans))
                        return true;
                    else
                        return false;

                }

            }

            return false;

        }



    }
}
