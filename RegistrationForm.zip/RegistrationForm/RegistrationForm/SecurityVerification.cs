﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RegistrationForm
{
    public partial class SecurityVerification : Form
    {
        //variable to store security code
        public string secCode = "";
        public SecurityVerification()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt7.Text != secCode)
            {
                MessageBox.Show("INCORRECT SECURITY CODE");
            }
            else
            {
                this.Hide();
                MessageBox.Show("LOGIN SUCCESSFULL");
                Application.Exit();
            }
        }
    }
}
