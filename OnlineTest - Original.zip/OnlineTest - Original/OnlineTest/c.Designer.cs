﻿namespace OnlineTest
{
    partial class c
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButtonq11 = new System.Windows.Forms.RadioButton();
            this.radioButtonq12 = new System.Windows.Forms.RadioButton();
            this.radioButtonq13 = new System.Windows.Forms.RadioButton();
            this.radioButtonq14 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonq31 = new System.Windows.Forms.RadioButton();
            this.radioButtonq32 = new System.Windows.Forms.RadioButton();
            this.radioButtonq33 = new System.Windows.Forms.RadioButton();
            this.radioButtonq34 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonq41 = new System.Windows.Forms.RadioButton();
            this.radiobuttonq42 = new System.Windows.Forms.RadioButton();
            this.radioButtonq43 = new System.Windows.Forms.RadioButton();
            this.radioButtonq44 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButtonq52 = new System.Windows.Forms.RadioButton();
            this.radioButtonq54 = new System.Windows.Forms.RadioButton();
            this.radioButtonq53 = new System.Windows.Forms.RadioButton();
            this.radioButtonq51 = new System.Windows.Forms.RadioButton();
            this.btnNext = new System.Windows.Forms.Button();
            this.radioButtonq21 = new System.Windows.Forms.RadioButton();
            this.radioButtonq22 = new System.Windows.Forms.RadioButton();
            this.radioButtonq23 = new System.Windows.Forms.RadioButton();
            this.radioButtonq24 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButtonq11);
            this.panel5.Controls.Add(this.radioButtonq12);
            this.panel5.Controls.Add(this.radioButtonq13);
            this.panel5.Controls.Add(this.radioButtonq14);
            this.panel5.Location = new System.Drawing.Point(82, 39);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(433, 28);
            this.panel5.TabIndex = 41;
            // 
            // radioButtonq11
            // 
            this.radioButtonq11.AutoSize = true;
            this.radioButtonq11.Location = new System.Drawing.Point(8, 5);
            this.radioButtonq11.Name = "radioButtonq11";
            this.radioButtonq11.Size = new System.Drawing.Size(68, 17);
            this.radioButtonq11.TabIndex = 5;
            this.radioButtonq11.TabStop = true;
            this.radioButtonq11.Text = "AB*CD*+";
            this.radioButtonq11.UseVisualStyleBackColor = true;
            // 
            // radioButtonq12
            // 
            this.radioButtonq12.AutoSize = true;
            this.radioButtonq12.Location = new System.Drawing.Point(118, 5);
            this.radioButtonq12.Name = "radioButtonq12";
            this.radioButtonq12.Size = new System.Drawing.Size(68, 17);
            this.radioButtonq12.TabIndex = 6;
            this.radioButtonq12.TabStop = true;
            this.radioButtonq12.Text = "A*BCD*+";
            this.radioButtonq12.UseVisualStyleBackColor = true;
            // 
            // radioButtonq13
            // 
            this.radioButtonq13.AutoSize = true;
            this.radioButtonq13.Location = new System.Drawing.Point(227, 5);
            this.radioButtonq13.Name = "radioButtonq13";
            this.radioButtonq13.Size = new System.Drawing.Size(71, 17);
            this.radioButtonq13.TabIndex = 7;
            this.radioButtonq13.TabStop = true;
            this.radioButtonq13.Text = " AB*CD+*";
            this.radioButtonq13.UseVisualStyleBackColor = true;
            // 
            // radioButtonq14
            // 
            this.radioButtonq14.AutoSize = true;
            this.radioButtonq14.Location = new System.Drawing.Point(328, 5);
            this.radioButtonq14.Name = "radioButtonq14";
            this.radioButtonq14.Size = new System.Drawing.Size(68, 17);
            this.radioButtonq14.TabIndex = 8;
            this.radioButtonq14.TabStop = true;
            this.radioButtonq14.Text = "A*B*CD+";
            this.radioButtonq14.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonq31);
            this.panel3.Controls.Add(this.radioButtonq32);
            this.panel3.Controls.Add(this.radioButtonq33);
            this.panel3.Controls.Add(this.radioButtonq34);
            this.panel3.Location = new System.Drawing.Point(82, 158);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(433, 28);
            this.panel3.TabIndex = 39;
            // 
            // radioButtonq31
            // 
            this.radioButtonq31.AutoSize = true;
            this.radioButtonq31.Location = new System.Drawing.Point(8, 3);
            this.radioButtonq31.Name = "radioButtonq31";
            this.radioButtonq31.Size = new System.Drawing.Size(102, 17);
            this.radioButtonq31.TabIndex = 13;
            this.radioButtonq31.TabStop = true;
            this.radioButtonq31.Text = "9’s complement ";
            this.radioButtonq31.UseVisualStyleBackColor = true;
            // 
            // radioButtonq32
            // 
            this.radioButtonq32.AutoSize = true;
            this.radioButtonq32.Location = new System.Drawing.Point(116, 3);
            this.radioButtonq32.Name = "radioButtonq32";
            this.radioButtonq32.Size = new System.Drawing.Size(105, 17);
            this.radioButtonq32.TabIndex = 14;
            this.radioButtonq32.TabStop = true;
            this.radioButtonq32.Text = "10’s complement";
            this.radioButtonq32.UseVisualStyleBackColor = true;
            // 
            // radioButtonq33
            // 
            this.radioButtonq33.AutoSize = true;
            this.radioButtonq33.Location = new System.Drawing.Point(227, 3);
            this.radioButtonq33.Name = "radioButtonq33";
            this.radioButtonq33.Size = new System.Drawing.Size(102, 17);
            this.radioButtonq33.TabIndex = 15;
            this.radioButtonq33.TabStop = true;
            this.radioButtonq33.Text = " 1’s complement";
            this.radioButtonq33.UseVisualStyleBackColor = true;
            // 
            // radioButtonq34
            // 
            this.radioButtonq34.AutoSize = true;
            this.radioButtonq34.Location = new System.Drawing.Point(331, 3);
            this.radioButtonq34.Name = "radioButtonq34";
            this.radioButtonq34.Size = new System.Drawing.Size(99, 17);
            this.radioButtonq34.TabIndex = 16;
            this.radioButtonq34.TabStop = true;
            this.radioButtonq34.Text = "2’s complement";
            this.radioButtonq34.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButtonq41);
            this.panel2.Controls.Add(this.radiobuttonq42);
            this.panel2.Controls.Add(this.radioButtonq43);
            this.panel2.Controls.Add(this.radioButtonq44);
            this.panel2.Location = new System.Drawing.Point(82, 217);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(433, 28);
            this.panel2.TabIndex = 38;
            // 
            // radioButtonq41
            // 
            this.radioButtonq41.AutoSize = true;
            this.radioButtonq41.Location = new System.Drawing.Point(6, 7);
            this.radioButtonq41.Name = "radioButtonq41";
            this.radioButtonq41.Size = new System.Drawing.Size(64, 17);
            this.radioButtonq41.TabIndex = 17;
            this.radioButtonq41.TabStop = true;
            this.radioButtonq41.Text = "too slow";
            this.radioButtonq41.UseVisualStyleBackColor = true;
            // 
            // radiobuttonq42
            // 
            this.radiobuttonq42.AutoSize = true;
            this.radiobuttonq42.Location = new System.Drawing.Point(118, 7);
            this.radiobuttonq42.Name = "radiobuttonq42";
            this.radiobuttonq42.Size = new System.Drawing.Size(70, 17);
            this.radiobuttonq42.TabIndex = 18;
            this.radiobuttonq42.TabStop = true;
            this.radiobuttonq42.Text = "unreliable";
            this.radiobuttonq42.UseVisualStyleBackColor = true;
            // 
            // radioButtonq43
            // 
            this.radioButtonq43.AutoSize = true;
            this.radioButtonq43.Location = new System.Drawing.Point(227, 3);
            this.radioButtonq43.Name = "radioButtonq43";
            this.radioButtonq43.Size = new System.Drawing.Size(76, 17);
            this.radioButtonq43.TabIndex = 19;
            this.radioButtonq43.TabStop = true;
            this.radioButtonq43.Text = "it is volatile";
            this.radioButtonq43.UseVisualStyleBackColor = true;
            // 
            // radioButtonq44
            // 
            this.radioButtonq44.AutoSize = true;
            this.radioButtonq44.Location = new System.Drawing.Point(331, 7);
            this.radioButtonq44.Name = "radioButtonq44";
            this.radioButtonq44.Size = new System.Drawing.Size(71, 17);
            this.radioButtonq44.TabIndex = 20;
            this.radioButtonq44.TabStop = true;
            this.radioButtonq44.Text = " too bulky";
            this.radioButtonq44.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButtonq52);
            this.panel1.Controls.Add(this.radioButtonq54);
            this.panel1.Controls.Add(this.radioButtonq53);
            this.panel1.Controls.Add(this.radioButtonq51);
            this.panel1.Location = new System.Drawing.Point(84, 277);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(433, 28);
            this.panel1.TabIndex = 37;
            // 
            // radioButtonq52
            // 
            this.radioButtonq52.AutoSize = true;
            this.radioButtonq52.Location = new System.Drawing.Point(120, 8);
            this.radioButtonq52.Name = "radioButtonq52";
            this.radioButtonq52.Size = new System.Drawing.Size(68, 17);
            this.radioButtonq52.TabIndex = 24;
            this.radioButtonq52.TabStop = true;
            this.radioButtonq52.Text = "Encoder ";
            this.radioButtonq52.UseVisualStyleBackColor = true;
            // 
            // radioButtonq54
            // 
            this.radioButtonq54.AutoSize = true;
            this.radioButtonq54.Location = new System.Drawing.Point(329, 8);
            this.radioButtonq54.Name = "radioButtonq54";
            this.radioButtonq54.Size = new System.Drawing.Size(67, 17);
            this.radioButtonq54.TabIndex = 22;
            this.radioButtonq54.TabStop = true;
            this.radioButtonq54.Text = " Flip Flop";
            this.radioButtonq54.UseVisualStyleBackColor = true;
            // 
            // radioButtonq53
            // 
            this.radioButtonq53.AutoSize = true;
            this.radioButtonq53.Location = new System.Drawing.Point(225, 8);
            this.radioButtonq53.Name = "radioButtonq53";
            this.radioButtonq53.Size = new System.Drawing.Size(66, 17);
            this.radioButtonq53.TabIndex = 23;
            this.radioButtonq53.TabStop = true;
            this.radioButtonq53.Text = "Decoder";
            this.radioButtonq53.UseVisualStyleBackColor = true;
            // 
            // radioButtonq51
            // 
            this.radioButtonq51.AutoSize = true;
            this.radioButtonq51.Location = new System.Drawing.Point(6, 8);
            this.radioButtonq51.Name = "radioButtonq51";
            this.radioButtonq51.Size = new System.Drawing.Size(70, 17);
            this.radioButtonq51.TabIndex = 25;
            this.radioButtonq51.TabStop = true;
            this.radioButtonq51.Text = " Register ";
            this.radioButtonq51.UseVisualStyleBackColor = true;
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(500, 316);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(125, 38);
            this.btnNext.TabIndex = 36;
            this.btnNext.Text = "Next ";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // radioButtonq21
            // 
            this.radioButtonq21.AutoSize = true;
            this.radioButtonq21.Location = new System.Drawing.Point(8, 8);
            this.radioButtonq21.Name = "radioButtonq21";
            this.radioButtonq21.Size = new System.Drawing.Size(98, 17);
            this.radioButtonq21.TabIndex = 9;
            this.radioButtonq21.TabStop = true;
            this.radioButtonq21.Text = "Boolean values";
            this.radioButtonq21.UseVisualStyleBackColor = true;
            // 
            // radioButtonq22
            // 
            this.radioButtonq22.AutoSize = true;
            this.radioButtonq22.Location = new System.Drawing.Point(116, 6);
            this.radioButtonq22.Name = "radioButtonq22";
            this.radioButtonq22.Size = new System.Drawing.Size(96, 17);
            this.radioButtonq22.TabIndex = 10;
            this.radioButtonq22.TabStop = true;
            this.radioButtonq22.Text = "whole numbers";
            this.radioButtonq22.UseVisualStyleBackColor = true;
            // 
            // radioButtonq23
            // 
            this.radioButtonq23.AutoSize = true;
            this.radioButtonq23.Location = new System.Drawing.Point(227, 6);
            this.radioButtonq23.Name = "radioButtonq23";
            this.radioButtonq23.Size = new System.Drawing.Size(82, 17);
            this.radioButtonq23.TabIndex = 11;
            this.radioButtonq23.TabStop = true;
            this.radioButtonq23.Text = "real integers";
            this.radioButtonq23.UseVisualStyleBackColor = true;
            // 
            // radioButtonq24
            // 
            this.radioButtonq24.AutoSize = true;
            this.radioButtonq24.Location = new System.Drawing.Point(331, 8);
            this.radioButtonq24.Name = "radioButtonq24";
            this.radioButtonq24.Size = new System.Drawing.Size(65, 17);
            this.radioButtonq24.TabIndex = 12;
            this.radioButtonq24.TabStop = true;
            this.radioButtonq24.Text = " integers";
            this.radioButtonq24.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButtonq21);
            this.panel4.Controls.Add(this.radioButtonq22);
            this.panel4.Controls.Add(this.radioButtonq23);
            this.panel4.Controls.Add(this.radioButtonq24);
            this.panel4.Location = new System.Drawing.Point(82, 95);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(433, 28);
            this.panel4.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(56, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(263, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "5.The circuit used to store one bit of data is known as ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(397, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "4.What characteristic of RAM memory makes it not suitable for permanent storage?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(260, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "3.In computers, subtraction is generally carried out by ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(226, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "2.Floating point representation is used to store ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(303, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "1.In Reverse Polish notation, expression A*B+C*D is written as ";
            // 
            // c
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 376);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "c";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "c";
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButtonq11;
        private System.Windows.Forms.RadioButton radioButtonq12;
        private System.Windows.Forms.RadioButton radioButtonq13;
        private System.Windows.Forms.RadioButton radioButtonq14;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButtonq31;
        private System.Windows.Forms.RadioButton radioButtonq32;
        private System.Windows.Forms.RadioButton radioButtonq33;
        private System.Windows.Forms.RadioButton radioButtonq34;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButtonq41;
        private System.Windows.Forms.RadioButton radiobuttonq42;
        private System.Windows.Forms.RadioButton radioButtonq43;
        private System.Windows.Forms.RadioButton radioButtonq44;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButtonq52;
        private System.Windows.Forms.RadioButton radioButtonq54;
        private System.Windows.Forms.RadioButton radioButtonq53;
        private System.Windows.Forms.RadioButton radioButtonq51;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.RadioButton radioButtonq21;
        private System.Windows.Forms.RadioButton radioButtonq22;
        private System.Windows.Forms.RadioButton radioButtonq23;
        private System.Windows.Forms.RadioButton radioButtonq24;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}