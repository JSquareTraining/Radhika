﻿namespace OnlineExam
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.rdbMale = new System.Windows.Forms.RadioButton();
            this.rdbfemale = new System.Windows.Forms.RadioButton();
            this.checkBoxC = new System.Windows.Forms.CheckBox();
            this.checkBoxCplus = new System.Windows.Forms.CheckBox();
            this.checkBoxDotNet = new System.Windows.Forms.CheckBox();
            this.btnnext = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Gender";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Subjects";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(150, 54);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(118, 20);
            this.txtname.TabIndex = 3;
            // 
            // rdbMale
            // 
            this.rdbMale.AutoSize = true;
            this.rdbMale.Location = new System.Drawing.Point(150, 116);
            this.rdbMale.Name = "rdbMale";
            this.rdbMale.Size = new System.Drawing.Size(48, 17);
            this.rdbMale.TabIndex = 4;
            this.rdbMale.TabStop = true;
            this.rdbMale.Text = "Male";
            this.rdbMale.UseVisualStyleBackColor = true;
            // 
            // rdbfemale
            // 
            this.rdbfemale.AutoSize = true;
            this.rdbfemale.Location = new System.Drawing.Point(241, 116);
            this.rdbfemale.Name = "rdbfemale";
            this.rdbfemale.Size = new System.Drawing.Size(59, 17);
            this.rdbfemale.TabIndex = 5;
            this.rdbfemale.TabStop = true;
            this.rdbfemale.Text = "Female";
            this.rdbfemale.UseVisualStyleBackColor = true;
            // 
            // checkBoxC
            // 
            this.checkBoxC.AutoSize = true;
            this.checkBoxC.Location = new System.Drawing.Point(150, 175);
            this.checkBoxC.Name = "checkBoxC";
            this.checkBoxC.Size = new System.Drawing.Size(33, 17);
            this.checkBoxC.TabIndex = 6;
            this.checkBoxC.Text = "C";
            this.checkBoxC.UseVisualStyleBackColor = true;
            // 
            // checkBoxCplus
            // 
            this.checkBoxCplus.AutoSize = true;
            this.checkBoxCplus.Location = new System.Drawing.Point(150, 198);
            this.checkBoxCplus.Name = "checkBoxCplus";
            this.checkBoxCplus.Size = new System.Drawing.Size(48, 17);
            this.checkBoxCplus.TabIndex = 7;
            this.checkBoxCplus.Text = "C ++";
            this.checkBoxCplus.UseVisualStyleBackColor = true;
            // 
            // checkBoxDotNet
            // 
            this.checkBoxDotNet.AutoSize = true;
            this.checkBoxDotNet.Location = new System.Drawing.Point(150, 221);
            this.checkBoxDotNet.Name = "checkBoxDotNet";
            this.checkBoxDotNet.Size = new System.Drawing.Size(60, 17);
            this.checkBoxDotNet.TabIndex = 8;
            this.checkBoxDotNet.Text = "VB.Net";
            this.checkBoxDotNet.UseVisualStyleBackColor = true;
            this.checkBoxDotNet.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // btnnext
            // 
            this.btnnext.Location = new System.Drawing.Point(273, 221);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(87, 29);
            this.btnnext.TabIndex = 9;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 262);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.checkBoxDotNet);
            this.Controls.Add(this.checkBoxCplus);
            this.Controls.Add(this.checkBoxC);
            this.Controls.Add(this.rdbfemale);
            this.Controls.Add(this.rdbMale);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Registration";
            this.Text = "Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.RadioButton rdbMale;
        private System.Windows.Forms.RadioButton rdbfemale;
        private System.Windows.Forms.CheckBox checkBoxC;
        private System.Windows.Forms.CheckBox checkBoxCplus;
        private System.Windows.Forms.CheckBox checkBoxDotNet;
        private System.Windows.Forms.Button btnnext;
    }
}