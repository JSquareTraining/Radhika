﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OnlineExam
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            {
                string name = "";
                string gender = "";

                if (txtname.Text == "")
                {
                    MessageBox.Show("No Name Entered");
                    return;
                }
                else
                {
                    name = txtname.Text;
                }

                if (!(rdbMale.Checked || rdbfemale.Checked))
                {
                    MessageBox.Show("No Gender Selected");
                    return;
                }
                else
                {
                    if (rdbMale.Checked)
                        gender = "Male";
                    else
                        gender = "FeMale";
                }

                if (!(checkBoxC.Checked || checkBoxCplus.Checked || checkBoxDotNet.Checked))
                {
                    MessageBox.Show("No Test Selected");
                    return;
                }


                if (checkBoxC.Checked)
                {
                    this.Hide();
                    C ctest = new C();
                    //ctest.checkBoxC = checkBoxC;
                    ctest.Show();
                    

                }
                else if (checkBoxCplus.Checked)
                {
                    this.Hide();
                    CPlusPlus cPlusTest = new CPlusPlus();
                    //cPlusTest.user = checkBoxCplus;
                    cPlusTest.Show();

                }
                else if (checkBoxDotNet.Checked)
                {
                    this.Hide();
                    VBNet vbTest = new VBNet();
                    //vbTest.user = checkBoxDotNet;
                   // vbTest.Show();

                }


            }
        }
    }
}
