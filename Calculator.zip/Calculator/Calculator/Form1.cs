﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void lbl2_Click(object sender, EventArgs e)
        {
            lbl2.Text = Convert.ToString(but14.Text);
        }

        //private void but13_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but13.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but13.Text);
        //    }
        //}

        //private void but1_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but1.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but1.Text);
        //    }
        //}

        //private void but2_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but2.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but2.Text);
        //    }
        //}

        //private void but3_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but3.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but3.Text);
        //    }
        //}

        //private void but4_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but4.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but4.Text);
        //    }
        //}

        //private void but5_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but5.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but5.Text);
        //    }
        //}

        //private void but6_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but6.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but6.Text);
        //    }
        //}

        //private void but7_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but7.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but7.Text);
        //    }
        //}

        //private void but8_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but8.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but8.Text);
        //    }
        //}

        //private void but9_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but9.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but9.Text);
        //    }

        //}

        //private void but15_Click(object sender, EventArgs e)
        //{
        //    lbl1.Text = Convert.ToString(but15.Text);
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "+")
        //        {
        //            int k = i + j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }
        //}



        //private void lbl1_Click(object sender, EventArgs e)
        //{

        //}

        //private void but12_Click(object sender, EventArgs e)
        //{
        //    lbl1.Text = Convert.ToString(but12.Text);
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "-")
        //        {
        //            int k = i - j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }

        //}

        //private void but11_Click(object sender, EventArgs e)
        //{
        //    lbl1.Text = Convert.ToString(but11.Text);
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "*")
        //        {
        //            int k = i * j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }

        //}

        //private void but10_Click(object sender, EventArgs e)
        //{
        //    lbl1.Text = Convert.ToString(but10.Text);
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "/")
        //        {
        //            int k = i / j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }

        //}

        //private void but16_Click(object sender, EventArgs e)
        //{
        //    if (lbl1.Text == "")
        //    {
        //        txt1.Text += Convert.ToString(but16.Text);
        //    }
        //    else
        //    {
        //        txt2.Text += Convert.ToString(but16.Text);
        //    }
        //}



        //private void txt2_TextChanged(object sender, EventArgs e)
        //{
        //    lbl2.Text = but14.Text;
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "+")
        //        {
        //            int k = i + j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "-")
        //        {
        //            int k = i - j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }
        //    if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "*")
        //        {
        //            int k = i * j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    } if (txt1.Text != "" && txt2.Text != "")
        //    {
        //        int i = Convert.ToInt32(txt1.Text);
        //        int j = Convert.ToInt32(txt2.Text);
        //        if (lbl1.Text == "/")
        //        {
        //            int k = i / j;
        //            txt3.Text = Convert.ToString(k);
        //        }
        //    }
        //}

        private void btnnumber_click(object sender, EventArgs e)
        {
            if (lbl1.Text == "")
            {
                txt1.Text += ((Button)sender).Text;
            }
            else
            {
                txt2.Text += ((Button)sender).Text;
            }
        }

        private void btnopr_click(object sender, EventArgs e)
        {
            lbl1.Text = ((Button)sender).Text;
        }


        private void but14_Click(object sender, EventArgs e)
        {
            {
                lbl2.Text = Convert.ToString(but14.Text);
            }
            {
                if (txt1.Text != "" && txt2.Text != "" && lbl1.Text != "")
                {
                    int a = Convert.ToInt32(txt1.Text);
                    int b = Convert.ToInt32(txt2.Text);
                    switch (lbl1.Text)
                    {
                        case "/":
                            txt3.Text = Convert.ToString(a / b);
                            break;
                        case "*":
                            txt3.Text = Convert.ToString(a * b);
                            break;
                        case "+":
                            txt3.Text = Convert.ToString(a + b);
                            break;
                        case "-":
                            txt3.Text = Convert.ToString(a - b);
                            break;
                            
                    }
                }
            }

        }
    }
}

        
        
        

