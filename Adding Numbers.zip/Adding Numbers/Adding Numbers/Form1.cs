﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Adding_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void txtval1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txtopr_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(txtval1.Text);
            int j = Convert.ToInt32(txtval2.Text);

            int k = 0;

            if (txtopr.Text == "+")
            {
                k = i + j;
            }
            else if (txtopr.Text == "-")
            {
                k = i - j;
            }
            else if (txtopr.Text == "*")
            {
                k = i * j;
            }
            txtresult.Text = Convert.ToString(k);
        }
        }

        
    }