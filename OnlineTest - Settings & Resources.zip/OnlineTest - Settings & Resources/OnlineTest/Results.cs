﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OnlineTest
{
    public partial class Results : Form
    {
        public c cForm = null;
        public cplusplus cplusplusForm= null;
        public vbdotnet vbdotnetForm = null;
        public Registration regForm = null;
        public Results()
        {
            InitializeComponent();
        }

        //Updates the label instance based on the boolean passed
        private void updateResultLabel(Label lbl, Boolean isCorrect)
        {
            if (isCorrect)
                lbl.BackColor = Color.Green;
            else
                lbl.BackColor = Color.Red;
        }

        public void displayResults()
        {
            if (cForm != null)
            {

                updateResultLabel(lblcq1, cForm.getResult(1));
                updateResultLabel(lblcq2, cForm.getResult(2));
                updateResultLabel(lblcq3, cForm.getResult(3));
                updateResultLabel(lblcq4, cForm.getResult(4));
                updateResultLabel(lblcq5, cForm.getResult(5));
            }
            else { groupBox1.Visible = false; }


            if (cplusplusForm != null)
            {

                updateResultLabel(lblcpq1, cplusplusForm.getResult(1));
                updateResultLabel(lblcpq2, cplusplusForm.getResult(2));
                updateResultLabel(lblcpq3, cplusplusForm.getResult(3));
                updateResultLabel(lblcpq4, cplusplusForm.getResult(4));
                updateResultLabel(lblcpq5, cplusplusForm.getResult(5));
            }
            else { groupBox2.Visible = false; }

            if (vbdotnetForm != null)
            {

                updateResultLabel(lblvbq1, vbdotnetForm.getResult(1));
                updateResultLabel(lblvbq2, vbdotnetForm.getResult(2));
                updateResultLabel(lblvbq3, vbdotnetForm.getResult(3));
                updateResultLabel(lblvbq4, vbdotnetForm.getResult(4));
                updateResultLabel(lblvbq5, vbdotnetForm.getResult(5));
            }
            else { groupBox3.Visible = false; }
        }
    }
}
