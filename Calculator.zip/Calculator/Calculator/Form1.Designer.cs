﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.but4 = new System.Windows.Forms.Button();
            this.but5 = new System.Windows.Forms.Button();
            this.but6 = new System.Windows.Forms.Button();
            this.but7 = new System.Windows.Forms.Button();
            this.but8 = new System.Windows.Forms.Button();
            this.but9 = new System.Windows.Forms.Button();
            this.but10 = new System.Windows.Forms.Button();
            this.but11 = new System.Windows.Forms.Button();
            this.but12 = new System.Windows.Forms.Button();
            this.but13 = new System.Windows.Forms.Button();
            this.but14 = new System.Windows.Forms.Button();
            this.but15 = new System.Windows.Forms.Button();
            this.but16 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(259, 32);
            this.lbl1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(0, 13);
            this.lbl1.TabIndex = 0;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(359, 29);
            this.lbl2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(0, 13);
            this.lbl2.TabIndex = 1;
            this.lbl2.Click += new System.EventHandler(this.lbl2_Click);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(167, 25);
            this.txt1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(68, 20);
            this.txt1.TabIndex = 2;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(287, 25);
            this.txt2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(68, 20);
            this.txt2.TabIndex = 3;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(401, 25);
            this.txt3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(100, 20);
            this.txt3.TabIndex = 4;
            this.txt3.Click += new System.EventHandler(this.but14_Click);
            // 
            // but1
            // 
            this.but1.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but1.Location = new System.Drawing.Point(167, 187);
            this.but1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(79, 62);
            this.but1.TabIndex = 5;
            this.but1.Text = "1";
            this.but1.UseVisualStyleBackColor = true;
            this.but1.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but2
            // 
            this.but2.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but2.Location = new System.Drawing.Point(252, 187);
            this.but2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(79, 62);
            this.but2.TabIndex = 6;
            this.but2.Text = "2";
            this.but2.UseVisualStyleBackColor = true;
            this.but2.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but3
            // 
            this.but3.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but3.Location = new System.Drawing.Point(337, 187);
            this.but3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(79, 62);
            this.but3.TabIndex = 7;
            this.but3.Text = "3";
            this.but3.UseVisualStyleBackColor = true;
            this.but3.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but4
            // 
            this.but4.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but4.Location = new System.Drawing.Point(167, 119);
            this.but4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(79, 62);
            this.but4.TabIndex = 8;
            this.but4.Text = "4";
            this.but4.UseVisualStyleBackColor = true;
            this.but4.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but5
            // 
            this.but5.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but5.Location = new System.Drawing.Point(252, 119);
            this.but5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(79, 62);
            this.but5.TabIndex = 9;
            this.but5.Text = "5";
            this.but5.UseVisualStyleBackColor = true;
            this.but5.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but6
            // 
            this.but6.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but6.Location = new System.Drawing.Point(337, 119);
            this.but6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(79, 62);
            this.but6.TabIndex = 10;
            this.but6.Text = "6";
            this.but6.UseVisualStyleBackColor = true;
            this.but6.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but7
            // 
            this.but7.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but7.Location = new System.Drawing.Point(167, 51);
            this.but7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but7.Name = "but7";
            this.but7.Size = new System.Drawing.Size(79, 62);
            this.but7.TabIndex = 11;
            this.but7.Text = "7";
            this.but7.UseVisualStyleBackColor = true;
            this.but7.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but8
            // 
            this.but8.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but8.Location = new System.Drawing.Point(252, 51);
            this.but8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but8.Name = "but8";
            this.but8.Size = new System.Drawing.Size(79, 62);
            this.but8.TabIndex = 12;
            this.but8.Text = "8";
            this.but8.UseVisualStyleBackColor = true;
            this.but8.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but9
            // 
            this.but9.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but9.Location = new System.Drawing.Point(337, 51);
            this.but9.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but9.Name = "but9";
            this.but9.Size = new System.Drawing.Size(79, 62);
            this.but9.TabIndex = 13;
            this.but9.Text = "9";
            this.but9.UseVisualStyleBackColor = true;
            this.but9.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but10
            // 
            this.but10.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but10.Location = new System.Drawing.Point(422, 51);
            this.but10.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but10.Name = "but10";
            this.but10.Size = new System.Drawing.Size(79, 62);
            this.but10.TabIndex = 14;
            this.but10.Text = "/";
            this.but10.UseVisualStyleBackColor = true;
            this.but10.Click += new System.EventHandler(this.btnopr_click);
            // 
            // but11
            // 
            this.but11.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but11.Location = new System.Drawing.Point(422, 119);
            this.but11.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but11.Name = "but11";
            this.but11.Size = new System.Drawing.Size(79, 62);
            this.but11.TabIndex = 15;
            this.but11.Text = "*";
            this.but11.UseVisualStyleBackColor = true;
            this.but11.Click += new System.EventHandler(this.btnopr_click);
            // 
            // but12
            // 
            this.but12.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but12.Location = new System.Drawing.Point(422, 187);
            this.but12.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but12.Name = "but12";
            this.but12.Size = new System.Drawing.Size(79, 62);
            this.but12.TabIndex = 16;
            this.but12.Text = "-";
            this.but12.UseVisualStyleBackColor = true;
            this.but12.Click += new System.EventHandler(this.btnopr_click);
            // 
            // but13
            // 
            this.but13.Font = new System.Drawing.Font("Bookman Old Style", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but13.Location = new System.Drawing.Point(169, 264);
            this.but13.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but13.Name = "but13";
            this.but13.Size = new System.Drawing.Size(79, 62);
            this.but13.TabIndex = 17;
            this.but13.Text = "0";
            this.but13.UseVisualStyleBackColor = true;
            this.but13.Click += new System.EventHandler(this.btnnumber_click);
            // 
            // but14
            // 
            this.but14.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but14.Location = new System.Drawing.Point(337, 264);
            this.but14.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but14.Name = "but14";
            this.but14.Size = new System.Drawing.Size(79, 62);
            this.but14.TabIndex = 18;
            this.but14.Text = "=";
            this.but14.UseVisualStyleBackColor = true;
            this.but14.Click += new System.EventHandler(this.but14_Click);
            // 
            // but15
            // 
            this.but15.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but15.Location = new System.Drawing.Point(422, 264);
            this.but15.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but15.Name = "but15";
            this.but15.Size = new System.Drawing.Size(79, 62);
            this.but15.TabIndex = 19;
            this.but15.Text = "+";
            this.but15.UseVisualStyleBackColor = true;
            this.but15.Click += new System.EventHandler(this.btnopr_click);
            // 
            // but16
            // 
            this.but16.Font = new System.Drawing.Font("Bookman Old Style", 18F);
            this.but16.Location = new System.Drawing.Point(252, 264);
            this.but16.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.but16.Name = "but16";
            this.but16.Size = new System.Drawing.Size(79, 62);
            this.but16.TabIndex = 20;
            this.but16.Text = ".";
            this.but16.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 335);
            this.Controls.Add(this.but16);
            this.Controls.Add(this.but15);
            this.Controls.Add(this.but14);
            this.Controls.Add(this.but13);
            this.Controls.Add(this.but12);
            this.Controls.Add(this.but11);
            this.Controls.Add(this.but10);
            this.Controls.Add(this.but9);
            this.Controls.Add(this.but8);
            this.Controls.Add(this.but7);
            this.Controls.Add(this.but6);
            this.Controls.Add(this.but5);
            this.Controls.Add(this.but4);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.Button but7;
        private System.Windows.Forms.Button but8;
        private System.Windows.Forms.Button but9;
        private System.Windows.Forms.Button but10;
        private System.Windows.Forms.Button but11;
        private System.Windows.Forms.Button but12;
        private System.Windows.Forms.Button but13;
        private System.Windows.Forms.Button but14;
        private System.Windows.Forms.Button but15;
        private System.Windows.Forms.Button but16;
    }
}

