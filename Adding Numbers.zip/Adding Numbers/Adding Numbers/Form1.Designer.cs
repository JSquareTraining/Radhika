﻿namespace Adding_Numbers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtval1 = new System.Windows.Forms.TextBox();
            this.txtval2 = new System.Windows.Forms.TextBox();
            this.txtopr = new System.Windows.Forms.TextBox();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.lblCn = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtval1
            // 
            this.txtval1.Location = new System.Drawing.Point(95, 55);
            this.txtval1.Name = "txtval1";
            this.txtval1.Size = new System.Drawing.Size(100, 20);
            this.txtval1.TabIndex = 0;
            this.txtval1.TextChanged += new System.EventHandler(this.txtval1_TextChanged_1);
            // 
            // txtval2
            // 
            this.txtval2.Location = new System.Drawing.Point(95, 104);
            this.txtval2.Name = "txtval2";
            this.txtval2.Size = new System.Drawing.Size(100, 20);
            this.txtval2.TabIndex = 1;
            // 
            // txtopr
            // 
            this.txtopr.Location = new System.Drawing.Point(95, 153);
            this.txtopr.Name = "txtopr";
            this.txtopr.Size = new System.Drawing.Size(100, 20);
            this.txtopr.TabIndex = 2;
            this.txtopr.TextChanged += new System.EventHandler(this.txtopr_TextChanged);
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(95, 201);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(100, 20);
            this.txtresult.TabIndex = 3;
            // 
            // lblCn
            // 
            this.lblCn.AutoSize = true;
            this.lblCn.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblCn.Location = new System.Drawing.Point(71, 21);
            this.lblCn.Name = "lblCn";
            this.lblCn.Size = new System.Drawing.Size(169, 22);
            this.lblCn.TabIndex = 4;
            this.lblCn.Text = "CalculatingNumbers";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lblCn);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.txtopr);
            this.Controls.Add(this.txtval2);
            this.Controls.Add(this.txtval1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtval1;
        private System.Windows.Forms.TextBox txtval2;
        private System.Windows.Forms.TextBox txtopr;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.Label lblCn;
    }
}

