﻿namespace OnlineTest
{
    partial class c
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNext = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButtonq11 = new System.Windows.Forms.RadioButton();
            this.radioButtonq12 = new System.Windows.Forms.RadioButton();
            this.radioButtonq13 = new System.Windows.Forms.RadioButton();
            this.radioButtonq14 = new System.Windows.Forms.RadioButton();
            this.radioButtonq54 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonq21 = new System.Windows.Forms.RadioButton();
            this.radioButtonq22 = new System.Windows.Forms.RadioButton();
            this.radioButtonq23 = new System.Windows.Forms.RadioButton();
            this.radioButtonq24 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButtonq41 = new System.Windows.Forms.RadioButton();
            this.radioButtonq42 = new System.Windows.Forms.RadioButton();
            this.radioButtonq43 = new System.Windows.Forms.RadioButton();
            this.radioButtonq44 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonq31 = new System.Windows.Forms.RadioButton();
            this.radioButtonq32 = new System.Windows.Forms.RadioButton();
            this.radioButtonq33 = new System.Windows.Forms.RadioButton();
            this.radioButtonq34 = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButtonq51 = new System.Windows.Forms.RadioButton();
            this.radioButtonq52 = new System.Windows.Forms.RadioButton();
            this.radioButtonq53 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(535, 492);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(125, 38);
            this.btnNext.TabIndex = 36;
            this.btnNext.Text = "Next ";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 433);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "Q";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 328);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Q";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Q";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "Q";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Q";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButtonq11);
            this.panel1.Controls.Add(this.radioButtonq12);
            this.panel1.Controls.Add(this.radioButtonq13);
            this.panel1.Controls.Add(this.radioButtonq14);
            this.panel1.Location = new System.Drawing.Point(81, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 80);
            this.panel1.TabIndex = 96;
            // 
            // radioButtonq11
            // 
            this.radioButtonq11.AutoSize = true;
            this.radioButtonq11.Location = new System.Drawing.Point(3, 3);
            this.radioButtonq11.Name = "radioButtonq11";
            this.radioButtonq11.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq11.TabIndex = 31;
            this.radioButtonq11.TabStop = true;
            this.radioButtonq11.Tag = "A";
            this.radioButtonq11.UseVisualStyleBackColor = true;
            // 
            // radioButtonq12
            // 
            this.radioButtonq12.AutoSize = true;
            this.radioButtonq12.Location = new System.Drawing.Point(3, 22);
            this.radioButtonq12.Name = "radioButtonq12";
            this.radioButtonq12.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq12.TabIndex = 32;
            this.radioButtonq12.TabStop = true;
            this.radioButtonq12.Tag = "B";
            this.radioButtonq12.UseVisualStyleBackColor = true;
            // 
            // radioButtonq13
            // 
            this.radioButtonq13.AutoSize = true;
            this.radioButtonq13.Location = new System.Drawing.Point(3, 41);
            this.radioButtonq13.Name = "radioButtonq13";
            this.radioButtonq13.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq13.TabIndex = 33;
            this.radioButtonq13.TabStop = true;
            this.radioButtonq13.Tag = "C";
            this.radioButtonq13.UseVisualStyleBackColor = true;
            // 
            // radioButtonq14
            // 
            this.radioButtonq14.AutoSize = true;
            this.radioButtonq14.Location = new System.Drawing.Point(3, 60);
            this.radioButtonq14.Name = "radioButtonq14";
            this.radioButtonq14.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq14.TabIndex = 34;
            this.radioButtonq14.TabStop = true;
            this.radioButtonq14.Tag = "D";
            this.radioButtonq14.UseVisualStyleBackColor = true;
            // 
            // radioButtonq54
            // 
            this.radioButtonq54.AutoSize = true;
            this.radioButtonq54.Location = new System.Drawing.Point(87, 509);
            this.radioButtonq54.Name = "radioButtonq54";
            this.radioButtonq54.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq54.TabIndex = 90;
            this.radioButtonq54.TabStop = true;
            this.radioButtonq54.Tag = "D";
            this.radioButtonq54.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButtonq21);
            this.panel2.Controls.Add(this.radioButtonq22);
            this.panel2.Controls.Add(this.radioButtonq23);
            this.panel2.Controls.Add(this.radioButtonq24);
            this.panel2.Location = new System.Drawing.Point(81, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(418, 76);
            this.panel2.TabIndex = 97;
            // 
            // radioButtonq21
            // 
            this.radioButtonq21.AutoSize = true;
            this.radioButtonq21.Location = new System.Drawing.Point(3, 3);
            this.radioButtonq21.Name = "radioButtonq21";
            this.radioButtonq21.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq21.TabIndex = 35;
            this.radioButtonq21.TabStop = true;
            this.radioButtonq21.Tag = "A";
            this.radioButtonq21.UseVisualStyleBackColor = true;
            // 
            // radioButtonq22
            // 
            this.radioButtonq22.AutoSize = true;
            this.radioButtonq22.Location = new System.Drawing.Point(3, 22);
            this.radioButtonq22.Name = "radioButtonq22";
            this.radioButtonq22.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq22.TabIndex = 36;
            this.radioButtonq22.TabStop = true;
            this.radioButtonq22.Tag = "B";
            this.radioButtonq22.UseVisualStyleBackColor = true;
            // 
            // radioButtonq23
            // 
            this.radioButtonq23.AutoSize = true;
            this.radioButtonq23.Location = new System.Drawing.Point(3, 41);
            this.radioButtonq23.Name = "radioButtonq23";
            this.radioButtonq23.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq23.TabIndex = 37;
            this.radioButtonq23.TabStop = true;
            this.radioButtonq23.Tag = "C";
            this.radioButtonq23.UseVisualStyleBackColor = true;
            // 
            // radioButtonq24
            // 
            this.radioButtonq24.AutoSize = true;
            this.radioButtonq24.Location = new System.Drawing.Point(3, 60);
            this.radioButtonq24.Name = "radioButtonq24";
            this.radioButtonq24.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq24.TabIndex = 38;
            this.radioButtonq24.TabStop = true;
            this.radioButtonq24.Tag = "D";
            this.radioButtonq24.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButtonq41);
            this.panel4.Controls.Add(this.radioButtonq42);
            this.panel4.Controls.Add(this.radioButtonq43);
            this.panel4.Controls.Add(this.radioButtonq44);
            this.panel4.Location = new System.Drawing.Point(81, 347);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(418, 79);
            this.panel4.TabIndex = 99;
            // 
            // radioButtonq41
            // 
            this.radioButtonq41.AutoSize = true;
            this.radioButtonq41.Location = new System.Drawing.Point(3, 3);
            this.radioButtonq41.Name = "radioButtonq41";
            this.radioButtonq41.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq41.TabIndex = 43;
            this.radioButtonq41.TabStop = true;
            this.radioButtonq41.Tag = "A";
            this.radioButtonq41.UseVisualStyleBackColor = true;
            // 
            // radioButtonq42
            // 
            this.radioButtonq42.AutoSize = true;
            this.radioButtonq42.Location = new System.Drawing.Point(3, 22);
            this.radioButtonq42.Name = "radioButtonq42";
            this.radioButtonq42.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq42.TabIndex = 44;
            this.radioButtonq42.TabStop = true;
            this.radioButtonq42.Tag = "B";
            this.radioButtonq42.UseVisualStyleBackColor = true;
            // 
            // radioButtonq43
            // 
            this.radioButtonq43.AutoSize = true;
            this.radioButtonq43.Location = new System.Drawing.Point(3, 41);
            this.radioButtonq43.Name = "radioButtonq43";
            this.radioButtonq43.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq43.TabIndex = 45;
            this.radioButtonq43.TabStop = true;
            this.radioButtonq43.Tag = "C";
            this.radioButtonq43.UseVisualStyleBackColor = true;
            // 
            // radioButtonq44
            // 
            this.radioButtonq44.AutoSize = true;
            this.radioButtonq44.Location = new System.Drawing.Point(3, 59);
            this.radioButtonq44.Name = "radioButtonq44";
            this.radioButtonq44.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq44.TabIndex = 46;
            this.radioButtonq44.TabStop = true;
            this.radioButtonq44.Tag = "D";
            this.radioButtonq44.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonq31);
            this.panel3.Controls.Add(this.radioButtonq32);
            this.panel3.Controls.Add(this.radioButtonq33);
            this.panel3.Controls.Add(this.radioButtonq34);
            this.panel3.Location = new System.Drawing.Point(81, 236);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(418, 84);
            this.panel3.TabIndex = 98;
            // 
            // radioButtonq31
            // 
            this.radioButtonq31.AutoSize = true;
            this.radioButtonq31.Location = new System.Drawing.Point(3, 6);
            this.radioButtonq31.Name = "radioButtonq31";
            this.radioButtonq31.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq31.TabIndex = 39;
            this.radioButtonq31.TabStop = true;
            this.radioButtonq31.Tag = "A";
            this.radioButtonq31.UseVisualStyleBackColor = true;
            // 
            // radioButtonq32
            // 
            this.radioButtonq32.AutoSize = true;
            this.radioButtonq32.Location = new System.Drawing.Point(3, 25);
            this.radioButtonq32.Name = "radioButtonq32";
            this.radioButtonq32.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq32.TabIndex = 40;
            this.radioButtonq32.TabStop = true;
            this.radioButtonq32.Tag = "B";
            this.radioButtonq32.UseVisualStyleBackColor = true;
            // 
            // radioButtonq33
            // 
            this.radioButtonq33.AutoSize = true;
            this.radioButtonq33.Location = new System.Drawing.Point(3, 42);
            this.radioButtonq33.Name = "radioButtonq33";
            this.radioButtonq33.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq33.TabIndex = 41;
            this.radioButtonq33.TabStop = true;
            this.radioButtonq33.Tag = "C";
            this.radioButtonq33.UseVisualStyleBackColor = true;
            // 
            // radioButtonq34
            // 
            this.radioButtonq34.AutoSize = true;
            this.radioButtonq34.Location = new System.Drawing.Point(3, 61);
            this.radioButtonq34.Name = "radioButtonq34";
            this.radioButtonq34.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq34.TabIndex = 42;
            this.radioButtonq34.TabStop = true;
            this.radioButtonq34.Tag = "D";
            this.radioButtonq34.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButtonq51);
            this.panel5.Controls.Add(this.radioButtonq52);
            this.panel5.Controls.Add(this.radioButtonq53);
            this.panel5.Location = new System.Drawing.Point(84, 449);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(418, 81);
            this.panel5.TabIndex = 100;
            // 
            // radioButtonq51
            // 
            this.radioButtonq51.AutoSize = true;
            this.radioButtonq51.Location = new System.Drawing.Point(3, 3);
            this.radioButtonq51.Name = "radioButtonq51";
            this.radioButtonq51.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq51.TabIndex = 47;
            this.radioButtonq51.TabStop = true;
            this.radioButtonq51.Tag = "A";
            this.radioButtonq51.UseVisualStyleBackColor = true;
            // 
            // radioButtonq52
            // 
            this.radioButtonq52.AutoSize = true;
            this.radioButtonq52.Location = new System.Drawing.Point(3, 22);
            this.radioButtonq52.Name = "radioButtonq52";
            this.radioButtonq52.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq52.TabIndex = 48;
            this.radioButtonq52.TabStop = true;
            this.radioButtonq52.Tag = "B";
            this.radioButtonq52.UseVisualStyleBackColor = true;
            // 
            // radioButtonq53
            // 
            this.radioButtonq53.AutoSize = true;
            this.radioButtonq53.Location = new System.Drawing.Point(3, 41);
            this.radioButtonq53.Name = "radioButtonq53";
            this.radioButtonq53.Size = new System.Drawing.Size(14, 13);
            this.radioButtonq53.TabIndex = 49;
            this.radioButtonq53.TabStop = true;
            this.radioButtonq53.Tag = "C";
            this.radioButtonq53.UseVisualStyleBackColor = true;
            // 
            // c
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 544);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.radioButtonq54);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "c";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "A";
            this.Text = "c";
            //this.Load += new System.EventHandler(this.c_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButtonq11;
        private System.Windows.Forms.RadioButton radioButtonq12;
        private System.Windows.Forms.RadioButton radioButtonq13;
        private System.Windows.Forms.RadioButton radioButtonq14;
        private System.Windows.Forms.RadioButton radioButtonq54;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButtonq21;
        private System.Windows.Forms.RadioButton radioButtonq22;
        private System.Windows.Forms.RadioButton radioButtonq23;
        private System.Windows.Forms.RadioButton radioButtonq24;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioButtonq41;
        private System.Windows.Forms.RadioButton radioButtonq42;
        private System.Windows.Forms.RadioButton radioButtonq43;
        private System.Windows.Forms.RadioButton radioButtonq44;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButtonq31;
        private System.Windows.Forms.RadioButton radioButtonq32;
        private System.Windows.Forms.RadioButton radioButtonq33;
        private System.Windows.Forms.RadioButton radioButtonq34;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButtonq51;
        private System.Windows.Forms.RadioButton radioButtonq52;
        private System.Windows.Forms.RadioButton radioButtonq53;
    }
}