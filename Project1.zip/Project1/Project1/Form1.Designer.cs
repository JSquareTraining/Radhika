﻿namespace Project1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblblack = new System.Windows.Forms.Label();
            this.lblwhite = new System.Windows.Forms.Label();
            this.lblblack1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbllightgrey = new System.Windows.Forms.Label();
            this.lblwhite1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblmarrown = new System.Windows.Forms.Label();
            this.lblbrown = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblred = new System.Windows.Forms.Label();
            this.lblpink = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblorange = new System.Windows.Forms.Label();
            this.lblyellow = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbllightgreen = new System.Windows.Forms.Label();
            this.lbldarkgreen = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblgold = new System.Windows.Forms.Label();
            this.lblcream = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblblue = new System.Windows.Forms.Label();
            this.lbllightblue = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblviolet = new System.Windows.Forms.Label();
            this.lblpurple = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lblaqua = new System.Windows.Forms.Label();
            this.lbllightaqua = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.lblgrey = new System.Windows.Forms.Label();
            this.lblScreen = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblblack
            // 
            this.lblblack.BackColor = System.Drawing.Color.Black;
            this.lblblack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblblack.Location = new System.Drawing.Point(66, 29);
            this.lblblack.Name = "lblblack";
            this.lblblack.Size = new System.Drawing.Size(40, 39);
            this.lblblack.TabIndex = 0;
            this.lblblack.BackColorChanged += new System.EventHandler(this.lbl_Clk);
            // 
            // lblwhite
            // 
            this.lblwhite.BackColor = System.Drawing.Color.White;
            this.lblwhite.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblwhite.Location = new System.Drawing.Point(132, 32);
            this.lblwhite.Name = "lblwhite";
            this.lblwhite.Size = new System.Drawing.Size(36, 36);
            this.lblwhite.TabIndex = 1;
            // 
            // lblblack1
            // 
            this.lblblack1.BackColor = System.Drawing.Color.Black;
            this.lblblack1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblblack1.Location = new System.Drawing.Point(216, 58);
            this.lblblack1.Name = "lblblack1";
            this.lblblack1.Size = new System.Drawing.Size(14, 13);
            this.lblblack1.TabIndex = 3;
            this.lblblack1.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Lavender;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(216, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 4;
            this.label2.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lbllightgrey
            // 
            this.lbllightgrey.BackColor = System.Drawing.Color.Silver;
            this.lbllightgrey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbllightgrey.Location = new System.Drawing.Point(246, 26);
            this.lbllightgrey.Name = "lbllightgrey";
            this.lbllightgrey.Size = new System.Drawing.Size(14, 13);
            this.lbllightgrey.TabIndex = 5;
            this.lbllightgrey.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblwhite1
            // 
            this.lblwhite1.BackColor = System.Drawing.Color.White;
            this.lblwhite1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblwhite1.Location = new System.Drawing.Point(246, 58);
            this.lblwhite1.Name = "lblwhite1";
            this.lblwhite1.Size = new System.Drawing.Size(14, 13);
            this.lblwhite1.TabIndex = 6;
            this.lblwhite1.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Lavender;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(246, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 7;
            this.label5.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblmarrown
            // 
            this.lblmarrown.BackColor = System.Drawing.Color.Maroon;
            this.lblmarrown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblmarrown.Location = new System.Drawing.Point(276, 26);
            this.lblmarrown.Name = "lblmarrown";
            this.lblmarrown.Size = new System.Drawing.Size(14, 13);
            this.lblmarrown.TabIndex = 8;
            this.lblmarrown.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblbrown
            // 
            this.lblbrown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblbrown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbrown.Location = new System.Drawing.Point(276, 58);
            this.lblbrown.Name = "lblbrown";
            this.lblbrown.Size = new System.Drawing.Size(14, 13);
            this.lblbrown.TabIndex = 9;
            this.lblbrown.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Lavender;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(276, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 10;
            this.label8.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblred
            // 
            this.lblred.BackColor = System.Drawing.Color.Red;
            this.lblred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblred.Location = new System.Drawing.Point(306, 26);
            this.lblred.Name = "lblred";
            this.lblred.Size = new System.Drawing.Size(14, 13);
            this.lblred.TabIndex = 11;
            this.lblred.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblpink
            // 
            this.lblpink.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lblpink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblpink.Location = new System.Drawing.Point(306, 58);
            this.lblpink.Name = "lblpink";
            this.lblpink.Size = new System.Drawing.Size(14, 13);
            this.lblpink.TabIndex = 12;
            this.lblpink.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Lavender;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(306, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 13);
            this.label11.TabIndex = 13;
            this.label11.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblorange
            // 
            this.lblorange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblorange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblorange.Location = new System.Drawing.Point(336, 26);
            this.lblorange.Name = "lblorange";
            this.lblorange.Size = new System.Drawing.Size(14, 13);
            this.lblorange.TabIndex = 14;
            this.lblorange.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblyellow
            // 
            this.lblyellow.BackColor = System.Drawing.Color.Yellow;
            this.lblyellow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblyellow.Location = new System.Drawing.Point(336, 58);
            this.lblyellow.Name = "lblyellow";
            this.lblyellow.Size = new System.Drawing.Size(14, 13);
            this.lblyellow.TabIndex = 15;
            this.lblyellow.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Lavender;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(336, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 13);
            this.label14.TabIndex = 16;
            this.label14.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lbllightgreen
            // 
            this.lbllightgreen.BackColor = System.Drawing.Color.Lime;
            this.lbllightgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbllightgreen.Location = new System.Drawing.Point(366, 26);
            this.lbllightgreen.Name = "lbllightgreen";
            this.lbllightgreen.Size = new System.Drawing.Size(14, 13);
            this.lbllightgreen.TabIndex = 17;
            this.lbllightgreen.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lbldarkgreen
            // 
            this.lbldarkgreen.BackColor = System.Drawing.Color.Green;
            this.lbldarkgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbldarkgreen.Location = new System.Drawing.Point(366, 58);
            this.lbldarkgreen.Name = "lbldarkgreen";
            this.lbldarkgreen.Size = new System.Drawing.Size(14, 13);
            this.lbldarkgreen.TabIndex = 18;
            this.lbldarkgreen.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Lavender;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(366, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 13);
            this.label17.TabIndex = 19;
            this.label17.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblgold
            // 
            this.lblgold.BackColor = System.Drawing.Color.Gold;
            this.lblgold.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblgold.Location = new System.Drawing.Point(396, 26);
            this.lblgold.Name = "lblgold";
            this.lblgold.Size = new System.Drawing.Size(14, 13);
            this.lblgold.TabIndex = 20;
            this.lblgold.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblcream
            // 
            this.lblcream.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblcream.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcream.Location = new System.Drawing.Point(396, 58);
            this.lblcream.Name = "lblcream";
            this.lblcream.Size = new System.Drawing.Size(14, 13);
            this.lblcream.TabIndex = 21;
            this.lblcream.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Lavender;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(396, 90);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(14, 13);
            this.label20.TabIndex = 22;
            this.label20.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblblue
            // 
            this.lblblue.BackColor = System.Drawing.Color.Blue;
            this.lblblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblblue.Location = new System.Drawing.Point(426, 26);
            this.lblblue.Name = "lblblue";
            this.lblblue.Size = new System.Drawing.Size(14, 13);
            this.lblblue.TabIndex = 23;
            this.lblblue.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lbllightblue
            // 
            this.lbllightblue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbllightblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbllightblue.Location = new System.Drawing.Point(426, 58);
            this.lbllightblue.Name = "lbllightblue";
            this.lbllightblue.Size = new System.Drawing.Size(14, 13);
            this.lbllightblue.TabIndex = 24;
            this.lbllightblue.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Lavender;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Location = new System.Drawing.Point(426, 90);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(14, 13);
            this.label23.TabIndex = 25;
            this.label23.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblviolet
            // 
            this.lblviolet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblviolet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblviolet.Location = new System.Drawing.Point(456, 26);
            this.lblviolet.Name = "lblviolet";
            this.lblviolet.Size = new System.Drawing.Size(14, 13);
            this.lblviolet.TabIndex = 26;
            this.lblviolet.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblpurple
            // 
            this.lblpurple.BackColor = System.Drawing.Color.Purple;
            this.lblpurple.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblpurple.Location = new System.Drawing.Point(456, 58);
            this.lblpurple.Name = "lblpurple";
            this.lblpurple.Size = new System.Drawing.Size(14, 13);
            this.lblpurple.TabIndex = 27;
            this.lblpurple.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Lavender;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Location = new System.Drawing.Point(456, 90);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(14, 13);
            this.label26.TabIndex = 28;
            this.label26.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblaqua
            // 
            this.lblaqua.BackColor = System.Drawing.Color.Aqua;
            this.lblaqua.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblaqua.Location = new System.Drawing.Point(486, 26);
            this.lblaqua.Name = "lblaqua";
            this.lblaqua.Size = new System.Drawing.Size(14, 13);
            this.lblaqua.TabIndex = 29;
            this.lblaqua.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lbllightaqua
            // 
            this.lbllightaqua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbllightaqua.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbllightaqua.Location = new System.Drawing.Point(486, 58);
            this.lbllightaqua.Name = "lbllightaqua";
            this.lbllightaqua.Size = new System.Drawing.Size(14, 13);
            this.lbllightaqua.TabIndex = 30;
            this.lbllightaqua.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Lavender;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Location = new System.Drawing.Point(486, 90);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 13);
            this.label29.TabIndex = 31;
            this.label29.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.MediumVioletRed;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label30.Location = new System.Drawing.Point(528, 32);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(36, 36);
            this.label30.TabIndex = 32;
            this.label30.UseWaitCursor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Consolas", 8.25F);
            this.label31.Location = new System.Drawing.Point(63, 80);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 26);
            this.label31.TabIndex = 33;
            this.label31.Text = " Color \r\n   1";
            this.label31.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Consolas", 8.25F);
            this.label32.Location = new System.Drawing.Point(125, 80);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 26);
            this.label32.TabIndex = 34;
            this.label32.Text = " Color \r\n   2\r\n";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Consolas", 8.25F);
            this.label33.Location = new System.Drawing.Point(341, 123);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(49, 13);
            this.label33.TabIndex = 35;
            this.label33.Text = " Colors";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(533, 80);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(43, 26);
            this.label34.TabIndex = 36;
            this.label34.Text = "Edit \r\nColors";
            // 
            // lblgrey
            // 
            this.lblgrey.BackColor = System.Drawing.Color.Gray;
            this.lblgrey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblgrey.Location = new System.Drawing.Point(216, 26);
            this.lblgrey.Name = "lblgrey";
            this.lblgrey.Size = new System.Drawing.Size(14, 13);
            this.lblgrey.TabIndex = 37;
            this.lblgrey.Click += new System.EventHandler(this.lbl_Clk);
            // 
            // lblScreen
            // 
            this.lblScreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblScreen.Location = new System.Drawing.Point(63, 166);
            this.lblScreen.Name = "lblScreen";
            this.lblScreen.Size = new System.Drawing.Size(501, 190);
            this.lblScreen.TabIndex = 38;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 365);
            this.Controls.Add(this.lblScreen);
            this.Controls.Add(this.lblgrey);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.lbllightaqua);
            this.Controls.Add(this.lblaqua);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.lblpurple);
            this.Controls.Add(this.lblviolet);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.lbllightblue);
            this.Controls.Add(this.lblblue);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lblcream);
            this.Controls.Add(this.lblgold);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.lbldarkgreen);
            this.Controls.Add(this.lbllightgreen);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblyellow);
            this.Controls.Add(this.lblorange);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblpink);
            this.Controls.Add(this.lblred);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblbrown);
            this.Controls.Add(this.lblmarrown);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblwhite1);
            this.Controls.Add(this.lbllightgrey);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblblack1);
            this.Controls.Add(this.lblwhite);
            this.Controls.Add(this.lblblack);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Paint";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblblack;
        private System.Windows.Forms.Label lblwhite;
        private System.Windows.Forms.Label lblblack1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbllightgrey;
        private System.Windows.Forms.Label lblwhite1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblmarrown;
        private System.Windows.Forms.Label lblbrown;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblred;
        private System.Windows.Forms.Label lblpink;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblorange;
        private System.Windows.Forms.Label lblyellow;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbllightgreen;
        private System.Windows.Forms.Label lbldarkgreen;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblgold;
        private System.Windows.Forms.Label lblcream;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblblue;
        private System.Windows.Forms.Label lbllightblue;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblviolet;
        private System.Windows.Forms.Label lblpurple;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblaqua;
        private System.Windows.Forms.Label lbllightaqua;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lblgrey;
        private System.Windows.Forms.Label lblScreen;
    }
}

