﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RegistrationForm
{
    public partial class Login : Form
    {
        public string username = "";
        public string password = "";
        public string email = "";
        public string seccode = "";
       // public Login(string userName,string password)
        public Login()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //If username is empty or not correct show error
            if (txtUsername.Text == "" || txtUsername.Text != username)
            {
                MessageBox.Show("INCORRECT USERNAME");
                return;                
            }

            //If password is empty or not correct show error
            if (txtpwd.Text == "" || txtpwd.Text != password)
            {
                MessageBox.Show("INCORRECT PASSWORD");
                return;                
            }
            
            SecurityVerification log = new SecurityVerification();
            log.secCode = seccode;
            this.Hide();
            log.Show();
                    
                


            }
        }
    }

