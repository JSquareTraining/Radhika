﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OnlineTest
{
    public partial class cplusplus : Form
    {
        public Results resultForm = null;
        public cplusplus()
        {
            InitializeComponent();
        }
        public bool cPLang;
        public bool cPplusPlus;
        public bool vPbdotnet;     
       
     
        private void btnNext_Click(object sender, EventArgs e)
        {

            if (!(radioButtonq11.Checked || radioButtonq12.Checked || radioButtonq13.Checked || radioButtonq14.Checked))
            {
                MessageBox.Show("No choice selected for question 1");
                return;
            }
            if (!(radioButtonq21.Checked || radioButtonq22.Checked || radioButtonq23.Checked || radioButtonq24.Checked))
            {
                MessageBox.Show("No choice selected for question 2");
                return;
            }
            if (!(radioButtonq31.Checked || radioButtonq32.Checked || radioButtonq33.Checked || radioButtonq34.Checked))
            {
                MessageBox.Show("No choice selected for question 3");
                return;
            }
            if (!(radioButtonq41.Checked || radioButtonq42.Checked || radioButtonq43.Checked || radioButtonq44.Checked))
            {
                MessageBox.Show("No choice selected for question 4");
                return;
            }
            if (!(radioButtonq51.Checked || radioButtonq52.Checked || radioButtonq53.Checked || radioButtonq54.Checked))
            {
                MessageBox.Show("No choice selected for question 5");
                return;
            }

            if (resultForm.regForm.checkBoxDotNet.Checked == true)
            {
                this.Hide();
                vbdotnet vbdotnetselected = new vbdotnet();
                resultForm.vbdotnetForm = vbdotnetselected;
                vbdotnetselected.resultForm = resultForm;
                vbdotnetselected.Show();
                return;
            }

            this.Hide();
            resultForm.displayResults();
            resultForm.Show();
        }

        public Boolean getResult(int questionNum)
        {
            if (questionNum == 1)
                return radioButtonq13.Checked;

            if (questionNum == 2)
                return radioButtonq24.Checked;

            if (questionNum == 3)
                return radioButtonq34.Checked;

            if (questionNum == 4)
                return radioButtonq43.Checked;

            if (questionNum == 5)
                return radioButtonq53.Checked;

            return false;

        }

       
    }
}
