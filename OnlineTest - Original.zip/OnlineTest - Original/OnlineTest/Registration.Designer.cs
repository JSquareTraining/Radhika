﻿namespace OnlineTest
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnnext = new System.Windows.Forms.Button();
            this.checkBoxDotNet = new System.Windows.Forms.CheckBox();
            this.checkBoxCplus = new System.Windows.Forms.CheckBox();
            this.checkBoxC = new System.Windows.Forms.CheckBox();
            this.rdbFemale = new System.Windows.Forms.RadioButton();
            this.rdbMale = new System.Windows.Forms.RadioButton();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblsubjects = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnnext
            // 
            this.btnnext.Location = new System.Drawing.Point(345, 256);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(87, 29);
            this.btnnext.TabIndex = 19;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // checkBoxDotNet
            // 
            this.checkBoxDotNet.AutoSize = true;
            this.checkBoxDotNet.Location = new System.Drawing.Point(188, 228);
            this.checkBoxDotNet.Name = "checkBoxDotNet";
            this.checkBoxDotNet.Size = new System.Drawing.Size(60, 17);
            this.checkBoxDotNet.TabIndex = 18;
            this.checkBoxDotNet.Text = "VB.Net";
            this.checkBoxDotNet.UseVisualStyleBackColor = true;
            // 
            // checkBoxCplus
            // 
            this.checkBoxCplus.AutoSize = true;
            this.checkBoxCplus.Location = new System.Drawing.Point(188, 205);
            this.checkBoxCplus.Name = "checkBoxCplus";
            this.checkBoxCplus.Size = new System.Drawing.Size(48, 17);
            this.checkBoxCplus.TabIndex = 17;
            this.checkBoxCplus.Text = "C ++";
            this.checkBoxCplus.UseVisualStyleBackColor = true;
            // 
            // checkBoxC
            // 
            this.checkBoxC.AutoSize = true;
            this.checkBoxC.Location = new System.Drawing.Point(188, 182);
            this.checkBoxC.Name = "checkBoxC";
            this.checkBoxC.Size = new System.Drawing.Size(33, 17);
            this.checkBoxC.TabIndex = 16;
            this.checkBoxC.Text = "C";
            this.checkBoxC.UseVisualStyleBackColor = true;
            // 
            // rdbFemale
            // 
            this.rdbFemale.AutoSize = true;
            this.rdbFemale.Location = new System.Drawing.Point(279, 123);
            this.rdbFemale.Name = "rdbFemale";
            this.rdbFemale.Size = new System.Drawing.Size(59, 17);
            this.rdbFemale.TabIndex = 15;
            this.rdbFemale.TabStop = true;
            this.rdbFemale.Text = "Female";
            this.rdbFemale.UseVisualStyleBackColor = true;
            // 
            // rdbMale
            // 
            this.rdbMale.AutoSize = true;
            this.rdbMale.Location = new System.Drawing.Point(188, 123);
            this.rdbMale.Name = "rdbMale";
            this.rdbMale.Size = new System.Drawing.Size(48, 17);
            this.rdbMale.TabIndex = 14;
            this.rdbMale.TabStop = true;
            this.rdbMale.Text = "Male";
            this.rdbMale.UseVisualStyleBackColor = true;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(188, 61);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(118, 20);
            this.txtname.TabIndex = 13;
            // 
            // lblsubjects
            // 
            this.lblsubjects.AutoSize = true;
            this.lblsubjects.Location = new System.Drawing.Point(83, 186);
            this.lblsubjects.Name = "lblsubjects";
            this.lblsubjects.Size = new System.Drawing.Size(48, 13);
            this.lblsubjects.TabIndex = 12;
            this.lblsubjects.Text = "Subjects";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(83, 123);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(42, 13);
            this.lblgender.TabIndex = 11;
            this.lblgender.Text = "Gender";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(83, 68);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(35, 13);
            this.lblname.TabIndex = 10;
            this.lblname.Text = "Name";
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 319);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.checkBoxDotNet);
            this.Controls.Add(this.checkBoxCplus);
            this.Controls.Add(this.checkBoxC);
            this.Controls.Add(this.rdbFemale);
            this.Controls.Add(this.rdbMale);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblsubjects);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.lblname);
            this.Name = "Registration";
            this.Text = "Registration";
           
        }

        #endregion

        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.RadioButton rdbFemale;
        private System.Windows.Forms.RadioButton rdbMale;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblsubjects;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblname;
        public System.Windows.Forms.CheckBox checkBoxDotNet;
        public System.Windows.Forms.CheckBox checkBoxCplus;
        public System.Windows.Forms.CheckBox checkBoxC;
    }
}

